
// In AuthController.register(), enforce required fields:
// firstName, lastName, phone, messenger (as "telegram:@nick" or "whatsapp:+7900...")
// Also require login OR email.
