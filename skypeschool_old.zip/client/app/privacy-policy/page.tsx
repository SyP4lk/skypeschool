export default function Page() {
  return (
    <main className="max-w-5xl mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">Политика конфиденциальности</h1>
      <section className="prose prose-zinc max-w-none">
        <p>Контент будет добавлен на основе макета. Это временная заглушка.</p>
      </section>
    </main>
  );
}
