export default function ReviewsPage() {
  return (
    <main className="max-w-4xl mx-auto px-4 py-10">
      <h1 className="text-2xl font-bold mb-6">Отзывы</h1>
      <p className="text-gray-800">Здесь будут отзывы учеников (контент возьмём из WebArchive).</p>
    </main>
  );
}